// routes/reservations.js  — Create & manage table reservations
const router = require('express').Router();
const db     = require('../db/database');
const { requireAuth, requireAdmin } = require('../middleware/auth');

// ── POST /api/reservations  (public) — submit a reservation ──────────────────
// Body: { first_name, last_name, email, phone?, date, party_size, special_notes? }
router.post('/', (req, res) => {
  const { first_name, last_name, email, phone, date, party_size, special_notes } = req.body;

  if (!first_name || !last_name || !email || !date || !party_size)
    return res.status(400).json({ error: 'first_name, last_name, email, date and party_size are required.' });

  // Basic date validation — must be today or future
  if (new Date(date) < new Date(new Date().toDateString()))
    return res.status(400).json({ error: 'Reservation date must be today or in the future.' });

  const result = db.prepare(`
    INSERT INTO reservations (first_name, last_name, email, phone, date, party_size, special_notes)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(first_name, last_name, email, phone || null, date, party_size, special_notes || null);

  const reservation = db.prepare('SELECT * FROM reservations WHERE id = ?').get(result.lastInsertRowid);
  res.status(201).json({
    message: `Reservation confirmed! We'll contact you at ${email} within 2 hours.`,
    reservation
  });
});

// ── GET /api/reservations  (admin) — list all ─────────────────────────────────
router.get('/', requireAdmin, (req, res) => {
  const { status, date } = req.query;
  let query = 'SELECT * FROM reservations';
  const conditions = [];
  const params     = [];

  if (status) { conditions.push('status = ?'); params.push(status); }
  if (date)   { conditions.push('date = ?');   params.push(date);   }

  if (conditions.length) query += ' WHERE ' + conditions.join(' AND ');
  query += ' ORDER BY date ASC, created_at ASC';

  res.json(db.prepare(query).all(...params));
});

// ── GET /api/reservations/mine  (customer) — own reservations ────────────────
router.get('/mine', requireAuth, (req, res) => {
  const rows = db.prepare(
    'SELECT * FROM reservations WHERE email = ? ORDER BY date DESC'
  ).all(req.user.email);
  res.json(rows);
});

// ── PATCH /api/reservations/:id/status  (admin) — update status ──────────────
// Body: { status: 'confirmed' | 'cancelled' | 'pending' }
router.patch('/:id/status', requireAdmin, (req, res) => {
  const { status } = req.body;
  const valid = ['pending','confirmed','cancelled'];

  if (!valid.includes(status))
    return res.status(400).json({ error: `status must be one of: ${valid.join(', ')}` });

  const existing = db.prepare('SELECT id FROM reservations WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Reservation not found.' });

  db.prepare('UPDATE reservations SET status = ? WHERE id = ?').run(status, req.params.id);
  res.json({ message: `Reservation ${req.params.id} marked as ${status}.` });
});

// ── DELETE /api/reservations/:id  (admin) ────────────────────────────────────
router.delete('/:id', requireAdmin, (req, res) => {
  const existing = db.prepare('SELECT id FROM reservations WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Reservation not found.' });

  db.prepare('DELETE FROM reservations WHERE id = ?').run(req.params.id);
  res.json({ message: 'Reservation deleted.' });
});

module.exports = router;
