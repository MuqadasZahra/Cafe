// routes/orders.js  — Online ordering + Stripe Checkout
const router = require('express').Router();
const db     = require('../db/database');
const { requireAuth, requireAdmin } = require('../middleware/auth');

let stripe;
try {
  stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
} catch {
  console.warn('⚠️  Stripe not configured. Set STRIPE_SECRET_KEY in .env');
}

// ── POST /api/orders/checkout  (customer) — create Stripe Checkout session ────
// Body: { items: [{ id, qty }], customer_email }
// Returns: { url } — redirect the frontend to this URL
router.post('/checkout', async (req, res) => {
  if (!stripe) return res.status(503).json({ error: 'Payment service not configured.' });

  const { items, customer_email } = req.body;

  if (!items || !Array.isArray(items) || items.length === 0)
    return res.status(400).json({ error: 'items array is required.' });
  if (!customer_email)
    return res.status(400).json({ error: 'customer_email is required.' });

  // Fetch each item from DB to get real prices (NEVER trust frontend prices)
  const lineItems  = [];
  const orderItems = [];
  let   total      = 0;

  for (const { id, qty } of items) {
    if (!id || !qty || qty < 1) continue;

    const item = db.prepare('SELECT * FROM menu_items WHERE id = ? AND available = 1').get(id);
    if (!item) return res.status(404).json({ error: `Menu item ${id} not found or unavailable.` });

    const quantity = Math.floor(qty);
    lineItems.push({
      price_data: {
        currency: 'aed',
        unit_amount: Math.round(item.price * 100), // Stripe uses lowest denomination (fils)
        product_data: {
          name: item.name,
          description: item.description.slice(0, 120),
          images: item.image_url ? [item.image_url] : [],
        },
      },
      quantity,
    });

    orderItems.push({ id: item.id, name: item.name, price: item.price, qty: quantity });
    total += item.price * quantity;
  }

  if (lineItems.length === 0)
    return res.status(400).json({ error: 'No valid items found.' });

  // Save order as pending before redirect
  const result = db.prepare(`
    INSERT INTO orders (user_id, customer_email, items_json, total, status)
    VALUES (?, ?, ?, ?, 'pending')
  `).run(req.user?.id || null, customer_email, JSON.stringify(orderItems), total);

  const orderId = result.lastInsertRowid;

  // Create Stripe Checkout session
  const session = await stripe.checkout.sessions.create({
    payment_method_types: ['card'],
    customer_email,
    line_items: lineItems,
    mode: 'payment',
    success_url: `${process.env.FRONTEND_URL}/order-success.html?order=${orderId}`,
    cancel_url:  `${process.env.FRONTEND_URL}/index.html#menu`,
    metadata: { orderId: String(orderId) },
  });

  // Store session ID for webhook verification
  db.prepare('UPDATE orders SET stripe_session = ? WHERE id = ?').run(session.id, orderId);

  res.json({ url: session.url, orderId });
});

// ── POST /api/orders/webhook  — Stripe calls this after payment ───────────────
// Must be raw body (not JSON parsed) — configured in server.js
router.post('/webhook', (req, res) => {
  if (!stripe) return res.sendStatus(400);

  const sig = req.headers['stripe-signature'];
  let event;

  try {
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error('Webhook signature failed:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    const orderId = session.metadata?.orderId;
    if (orderId) {
      db.prepare('UPDATE orders SET status = ? WHERE id = ?').run('paid', orderId);
      console.log(`✅ Order #${orderId} marked as paid.`);
    }
  }

  res.sendStatus(200);
});

// ── GET /api/orders  (admin) — all orders ─────────────────────────────────────
router.get('/', requireAdmin, (req, res) => {
  const { status } = req.query;
  let query = 'SELECT * FROM orders';
  if (status) query += ' WHERE status = ?';
  query += ' ORDER BY created_at DESC';
  res.json(db.prepare(query).all(...(status ? [status] : [])));
});

// ── GET /api/orders/mine  (customer) — own orders ─────────────────────────────
router.get('/mine', requireAuth, (req, res) => {
  const rows = db.prepare(
    'SELECT * FROM orders WHERE user_id = ? OR customer_email = ? ORDER BY created_at DESC'
  ).all(req.user.id, req.user.email);
  res.json(rows);
});

// ── GET /api/orders/:id  (protected) — single order ──────────────────────────
router.get('/:id', requireAuth, (req, res) => {
  const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found.' });

  // Customers can only see their own orders
  if (req.user.role !== 'admin' && order.customer_email !== req.user.email && order.user_id !== req.user.id)
    return res.status(403).json({ error: 'Access denied.' });

  res.json({ ...order, items: JSON.parse(order.items_json) });
});

// ── PATCH /api/orders/:id/status  (admin) — update status ────────────────────
router.patch('/:id/status', requireAdmin, (req, res) => {
  const { status } = req.body;
  const valid = ['pending','paid','preparing','ready','cancelled'];

  if (!valid.includes(status))
    return res.status(400).json({ error: `status must be one of: ${valid.join(', ')}` });

  const existing = db.prepare('SELECT id FROM orders WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Order not found.' });

  db.prepare('UPDATE orders SET status = ? WHERE id = ?').run(status, req.params.id);
  res.json({ message: `Order #${req.params.id} is now ${status}.` });
});

module.exports = router;
