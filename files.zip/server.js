// server.js  — Brewhaus API entry point
require('dotenv').config();

const express = require('express');
const cors    = require('cors');
const app     = express();

// ── STRIPE WEBHOOK — must come BEFORE express.json() ──────────────────────────
// Stripe needs the raw body to verify signatures
app.use('/api/orders/webhook',
  express.raw({ type: 'application/json' }),
  require('./routes/orders').stack
    ? require('./routes/orders')           // already a router
    : (req, res) => res.sendStatus(500)
);

// ── GLOBAL MIDDLEWARE ──────────────────────────────────────────────────────────
app.use(cors({
  origin: process.env.FRONTEND_URL || '*',
  credentials: true,
}));

app.use(express.json());         // parse JSON bodies
app.use(express.urlencoded({ extended: true }));

// ── ROUTES ────────────────────────────────────────────────────────────────────
app.use('/api/auth',         require('./routes/auth'));
app.use('/api/menu',         require('./routes/menu'));
app.use('/api/reservations', require('./routes/reservations'));
app.use('/api/orders',       require('./routes/orders'));

// ── HEALTH CHECK ──────────────────────────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'Brewhaus API',
    version: '1.0.0',
    timestamp: new Date().toISOString(),
  });
});

// ── 404 ───────────────────────────────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ error: `Route ${req.method} ${req.path} not found.` });
});

// ── GLOBAL ERROR HANDLER ──────────────────────────────────────────────────────
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ error: 'Internal server error.' });
});

// ── START ─────────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`\n☕ Brewhaus API running at http://localhost:${PORT}`);
  console.log(`   Health: http://localhost:${PORT}/api/health`);
  console.log(`   Menu:   http://localhost:${PORT}/api/menu\n`);
});
