# ☕ BREWHAUS — Backend API

Full REST API for the Brewhaus Coffee Shop website.
Built with **Node.js + Express + SQLite + Stripe**.

---

## 📁 Folder Structure

```
brewhaus-backend/
├── server.js                  ← Entry point — starts the API server
├── package.json               ← Dependencies list
├── .env.example               ← Copy this to .env and fill in your keys
│
├── db/
│   ├── database.js            ← SQLite setup, table creation, seed data
│   └── brewhaus.db            ← Auto-created on first run (DO NOT commit)
│
├── middleware/
│   └── auth.js                ← JWT verify + admin guard
│
└── routes/
    ├── auth.js                ← Register, Login, Profile
    ├── menu.js                ← Full menu CRUD
    ├── reservations.js        ← Table reservation management
    └── orders.js              ← Online ordering + Stripe payments
```

---

## 🛠️ Required Software

| Software | Download |
|----------|----------|
| **Node.js** (v18 or newer) | https://nodejs.org — download LTS version |
| **VS Code** (recommended) | https://code.visualstudio.com |
| Any browser | Chrome, Firefox, Edge |

You do NOT need to install a database — SQLite is a file and works automatically.

---

## 🚀 Step-by-Step Setup

### Step 1 — Download Node.js
Go to https://nodejs.org and download the **LTS** version.
Run the installer, click Next through everything. To confirm it worked:
```bash
node --version
# should print something like: v20.11.0
```

### Step 2 — Open the project in VS Code
Open VS Code → File → Open Folder → select the `brewhaus-backend` folder.

### Step 3 — Open the terminal
In VS Code: **Terminal → New Terminal** (or press Ctrl+`` ` ``).

### Step 4 — Install dependencies
```bash
npm install
```
This downloads all required packages into a `node_modules/` folder.

### Step 5 — Set up environment variables
```bash
# Windows (Command Prompt):
copy .env.example .env

# Mac / Linux:
cp .env.example .env
```
Then open `.env` and fill in your values (see Configuration section below).

### Step 6 — Start the server
```bash
# Production mode:
npm start

# Development mode (auto-restarts on file changes):
npm run dev
```

You should see:
```
☕ Brewhaus API running at http://localhost:3000
   Health: http://localhost:3000/api/health
   Menu:   http://localhost:3000/api/menu
```

### Step 7 — Test it works
Open your browser and visit:
```
http://localhost:3000/api/health
http://localhost:3000/api/menu
```
You should see JSON data.

---

## ⚙️ Configuration (.env file)

```env
PORT=3000
JWT_SECRET=any_long_random_string_here

# Stripe keys — from https://dashboard.stripe.com/test/apikeys
STRIPE_SECRET_KEY=sk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...

# Your frontend URL (where index.html is served from)
FRONTEND_URL=http://localhost:5500
```

**Getting Stripe keys (free test mode):**
1. Go to https://stripe.com → create a free account
2. Dashboard → Developers → API keys
3. Copy the **Secret key** (starts with `sk_test_`)
4. For webhooks: Stripe CLI → `stripe listen --forward-to localhost:3000/api/orders/webhook`

---

## 📡 API Reference

### AUTH
| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/api/auth/register` | — | Create account |
| POST | `/api/auth/login` | — | Login, returns JWT |
| GET | `/api/auth/me` | JWT | Your profile |

**Register / Login body:**
```json
{ "name": "Ahmed", "email": "ahmed@example.com", "password": "secret123" }
```

**Using the JWT token:** add this header to protected requests:
```
Authorization: Bearer <your_token_here>
```

---

### MENU
| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/api/menu` | — | All available items |
| GET | `/api/menu?category=espresso` | — | Filter by category |
| GET | `/api/menu/:id` | — | Single item |
| POST | `/api/menu` | Admin | Add new item |
| PATCH | `/api/menu/:id` | Admin | Edit item |
| DELETE | `/api/menu/:id` | Admin | Delete item |

**Categories:** `espresso` · `black` · `cold` · `mocha` · `whipped`

**Add item body (admin):**
```json
{
  "category": "espresso",
  "name": "Oat Flat White",
  "description": "Velvety oat milk and double ristretto.",
  "price": 30,
  "badge": "Vegan",
  "image_url": "https://..."
}
```

---

### RESERVATIONS
| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/api/reservations` | — | Submit reservation |
| GET | `/api/reservations` | Admin | All reservations |
| GET | `/api/reservations/mine` | JWT | Your reservations |
| PATCH | `/api/reservations/:id/status` | Admin | Confirm/cancel |

**Submit body:**
```json
{
  "first_name": "Ahmed",
  "last_name": "Al-Rashid",
  "email": "ahmed@example.com",
  "phone": "+971 50 000 0000",
  "date": "2025-12-25",
  "party_size": 4,
  "special_notes": "Birthday celebration"
}
```

---

### ORDERS & PAYMENTS
| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/api/orders/checkout` | JWT | Create Stripe payment |
| GET | `/api/orders/mine` | JWT | Your orders |
| GET | `/api/orders` | Admin | All orders |
| PATCH | `/api/orders/:id/status` | Admin | Update order status |
| POST | `/api/orders/webhook` | Stripe | Payment confirmation |

**Checkout body:**
```json
{
  "items": [
    { "id": 1, "qty": 2 },
    { "id": 5, "qty": 1 }
  ],
  "customer_email": "ahmed@example.com"
}
```
→ Returns `{ "url": "https://checkout.stripe.com/..." }` — redirect user there.

---

## 🔐 Making Your First Admin Account

1. Register a normal account via `POST /api/auth/register`
2. Login via `POST /api/auth/login` — copy the token
3. Call `POST /api/auth/make-admin` with that token
4. Now you can manage the menu, view all orders, etc.

> Remove the `/make-admin` endpoint before going live!

---

## 🃏 Stripe Test Cards

Use these card numbers in test mode — no real money is charged:
- ✅ Success: `4242 4242 4242 4242`
- ❌ Decline: `4000 0000 0000 0002`
- Any future expiry date, any 3-digit CVC, any ZIP.

---

## 🌐 Connecting the Frontend

In your `index.html`, replace the form submission with a `fetch` call:

```javascript
// Example: submit reservation from the frontend
async function submitReservation(formData) {
  const res = await fetch('http://localhost:3000/api/reservations', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(formData)
  });
  const data = await res.json();
  console.log(data.message); // "Reservation confirmed!"
}
```

---

## 📦 All NPM Packages Explained

| Package | What it does |
|---------|-------------|
| `express` | Web server framework |
| `better-sqlite3` | SQLite database (no separate install needed) |
| `bcryptjs` | Hashes passwords securely |
| `jsonwebtoken` | Creates & verifies login tokens |
| `cors` | Allows the frontend to talk to the API |
| `dotenv` | Loads your .env file |
| `stripe` | Processes card payments |
| `nodemon` | Auto-restarts server during development |
