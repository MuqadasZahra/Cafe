// db/database.js  — SQLite setup + seed data
const Database = require('better-sqlite3');
const path     = require('path');

const db = new Database(path.join(__dirname, 'brewhaus.db'));

// Enable WAL mode for better performance
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// ── CREATE TABLES ──────────────────────────────────────────────────────────────

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT    NOT NULL,
    email      TEXT    NOT NULL UNIQUE,
    password   TEXT    NOT NULL,
    role       TEXT    NOT NULL DEFAULT 'customer',  -- 'customer' | 'admin'
    created_at TEXT    NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS menu_items (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    category    TEXT    NOT NULL,   -- espresso | black | cold | mocha | whipped
    name        TEXT    NOT NULL,
    description TEXT    NOT NULL,
    price       REAL    NOT NULL,
    badge       TEXT,               -- e.g. 'Bestseller', 'New', NULL
    image_url   TEXT,
    available   INTEGER NOT NULL DEFAULT 1,  -- 1 = yes, 0 = no
    created_at  TEXT    NOT NULL DEFAULT (datetime('now')),
    updated_at  TEXT    NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS reservations (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    first_name    TEXT    NOT NULL,
    last_name     TEXT    NOT NULL,
    email         TEXT    NOT NULL,
    phone         TEXT,
    date          TEXT    NOT NULL,
    party_size    INTEGER NOT NULL,
    special_notes TEXT,
    status        TEXT    NOT NULL DEFAULT 'pending',  -- pending | confirmed | cancelled
    created_at    TEXT    NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS orders (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id         INTEGER REFERENCES users(id),
    customer_email  TEXT    NOT NULL,
    items_json      TEXT    NOT NULL,  -- JSON array of {id, name, price, qty}
    total           REAL    NOT NULL,
    status          TEXT    NOT NULL DEFAULT 'pending',  -- pending | paid | preparing | ready | cancelled
    stripe_session  TEXT,
    created_at      TEXT    NOT NULL DEFAULT (datetime('now'))
  );
`);

// ── SEED MENU ITEMS (only if table is empty) ───────────────────────────────────

const count = db.prepare('SELECT COUNT(*) AS n FROM menu_items').get().n;

if (count === 0) {
  const insert = db.prepare(`
    INSERT INTO menu_items (category, name, description, price, badge, image_url)
    VALUES (@category, @name, @description, @price, @badge, @image_url)
  `);

  const seedMany = db.transaction((items) => items.forEach(i => insert.run(i)));

  seedMany([
    // ── ESPRESSO ──
    { category:'espresso', name:'Classic Espresso',  description:'A bold concentrated shot — rich crema, deep dark chocolate finish.', price:18, badge:'Classic',    image_url:'https://images.unsplash.com/photo-1510591509098-f4fdc6d0ff04?w=600&q=80' },
    { category:'espresso', name:'Double Ristretto',  description:'Half the water, double the intensity. Syrupy, sweet, dangerously smooth.',  price:22, badge:'Strong',     image_url:'https://images.unsplash.com/photo-1461023058943-07fcbe16d735?w=600&q=80' },
    { category:'espresso', name:'Flat White',        description:'Velvety micro-foam melts into a double ristretto. The Antipodean icon, perfected.', price:26, badge:'Bestseller', image_url:'https://images.unsplash.com/photo-1570968915860-54d5c301fa9f?w=600&q=80' },
    { category:'espresso', name:'Cortado',           description:'Equal parts espresso and warm milk — balanced, delicate, utterly satisfying.', price:24, badge:null,         image_url:'https://images.unsplash.com/photo-1572097440906-8cdf9f0b5bc6?w=600&q=80' },
    { category:'espresso', name:'Cappuccino',        description:'One-third espresso, one-third steamed milk, one-third dream.', price:28, badge:null,         image_url:'https://images.unsplash.com/photo-1534778101976-62847782c213?w=600&q=80' },
    { category:'espresso', name:'Piccolo Latte',     description:'A concentrated latte in a 100ml glass. Big flavour, small footprint.', price:25, badge:null,         image_url:'https://images.unsplash.com/photo-1559496417-e7f25cb247f3?w=600&q=80' },
    // ── BLACK ──
    { category:'black', name:'Pour Over',   description:'Single-origin beans, hand-ground, brewed slowly through a Chemex.', price:30, badge:'Specialty', image_url:'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=600&q=80' },
    { category:'black', name:'Aeropress',   description:'Pressure-brewed in 90 seconds for a rich, grit-free cup.', price:28, badge:null,       image_url:'https://images.unsplash.com/photo-1603384167703-fc2f8024c0cf?w=600&q=80' },
    { category:'black', name:'Americano',   description:'Hot water over a double shot — opens up the espresso\'s character beautifully.', price:22, badge:'Popular',  image_url:'https://images.unsplash.com/photo-1521302080334-4bebac2763a6?w=600&q=80' },
    { category:'black', name:'Long Black',  description:'Espresso poured into hot water — preserves the crema, maximum depth.', price:23, badge:null,       image_url:'https://images.unsplash.com/photo-1510591509098-f4fdc6d0ff04?w=600&q=80' },
    // ── COLD ──
    { category:'cold', name:'Cold Brew',        description:'Steeped 20 hours in cold water. Naturally sweet, low-acid, impossibly smooth.', price:32, badge:'Signature',   image_url:'https://images.unsplash.com/photo-1461023058943-07fcbe16d735?w=600&q=80' },
    { category:'cold', name:'Iced Latte',       description:'Double shot over ice, crowned with whole, oat, or almond milk.', price:30, badge:null,           image_url:'https://images.unsplash.com/photo-1551030173-122aabc4489c?w=600&q=80' },
    { category:'cold', name:'Nitro Cold Brew',  description:'Cold brew infused with nitrogen — silky, cascading, creamy head.', price:36, badge:'New',          image_url:'https://images.unsplash.com/photo-1506619216599-9d16d0903dfd?w=600&q=80' },
    { category:'cold', name:'Cold Brew Tonic',  description:'Cold brew meets premium tonic water — unexpected and refreshing.', price:34, badge:"Chef's Pick", image_url:'https://images.unsplash.com/photo-1570968915860-54d5c301fa9f?w=600&q=80' },
    // ── MOCHA ──
    { category:'mocha', name:'Classic Mocha',   description:'House-made dark chocolate ganache, double espresso, steamed milk.', price:32, badge:'Bestseller', image_url:'https://images.unsplash.com/photo-1534778101976-62847782c213?w=600&q=80' },
    { category:'mocha', name:'White Mocha',     description:'Silky white chocolate, espresso, steamed milk — sweeter and indulgent.', price:33, badge:null,         image_url:'https://images.unsplash.com/photo-1583577612013-4349b2cf3d27?w=600&q=80' },
    { category:'mocha', name:'Iced Mocha',      description:'Our beloved mocha, over ice. Chocolate, cold milk, rich espresso layers.', price:34, badge:null,         image_url:'https://images.unsplash.com/photo-1461023058943-07fcbe16d735?w=600&q=80' },
    { category:'mocha', name:'Hazelnut Mocha',  description:'Roasted hazelnut praline meets dark chocolate and espresso.', price:35, badge:'Seasonal',   image_url:'https://images.unsplash.com/photo-1559496417-e7f25cb247f3?w=600&q=80' },
    // ── WHIPPED ──
    { category:'whipped', name:'Dalgona Latte',     description:'Whipped coffee foam floats on a cloud of cold milk. A trending icon.', price:36, badge:'Trending',  image_url:'https://images.unsplash.com/photo-1606791422814-b32c705e3e2f?w=600&q=80' },
    { category:'whipped', name:'Whipped Caramel',   description:'Airy caramel whip, espresso, warm oat milk. Dessert meets coffee.', price:38, badge:'Signature',  image_url:'https://images.unsplash.com/photo-1551030173-122aabc4489c?w=600&q=80' },
    { category:'whipped', name:'Matcha Whip',       description:'Ceremonial-grade matcha beneath a cloud of sweet cream.', price:37, badge:null,          image_url:'https://images.unsplash.com/photo-1568649929103-28ffbefaca1e?w=600&q=80' },
    { category:'whipped', name:'Strawberry Whip',   description:'Fresh strawberry reduction, vanilla cold brew, lightly sweetened whipped cream.', price:38, badge:'Summer',     image_url:'https://images.unsplash.com/photo-1570968915860-54d5c301fa9f?w=600&q=80' },
  ]);

  console.log('✅ Database seeded with menu items.');
}

module.exports = db;
