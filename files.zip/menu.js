// routes/menu.js  — Menu CRUD
// GET  (public)  — browse menu
// POST / PATCH / DELETE  (admin only) — manage items
const router = require('express').Router();
const db     = require('../db/database');
const { requireAdmin } = require('../middleware/auth');

// ── GET /api/menu  — all available items, optionally filtered by category ──────
router.get('/', (req, res) => {
  const { category } = req.query;
  let stmt;
  if (category) {
    stmt = db.prepare('SELECT * FROM menu_items WHERE available = 1 AND category = ? ORDER BY id').all(category);
  } else {
    stmt = db.prepare('SELECT * FROM menu_items WHERE available = 1 ORDER BY category, id').all();
  }
  res.json(stmt);
});

// ── GET /api/menu/all  (admin) — includes unavailable items ───────────────────
router.get('/all', requireAdmin, (req, res) => {
  const items = db.prepare('SELECT * FROM menu_items ORDER BY category, id').all();
  res.json(items);
});

// ── GET /api/menu/:id  ────────────────────────────────────────────────────────
router.get('/:id', (req, res) => {
  const item = db.prepare('SELECT * FROM menu_items WHERE id = ?').get(req.params.id);
  if (!item) return res.status(404).json({ error: 'Item not found.' });
  res.json(item);
});

// ── POST /api/menu  (admin) — create new item ─────────────────────────────────
// Body: { category, name, description, price, badge?, image_url?, available? }
router.post('/', requireAdmin, (req, res) => {
  const { category, name, description, price, badge, image_url, available } = req.body;

  if (!category || !name || !description || !price)
    return res.status(400).json({ error: 'category, name, description and price are required.' });

  const validCategories = ['espresso','black','cold','mocha','whipped'];
  if (!validCategories.includes(category))
    return res.status(400).json({ error: `category must be one of: ${validCategories.join(', ')}` });

  const result = db.prepare(`
    INSERT INTO menu_items (category, name, description, price, badge, image_url, available)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(category, name, description, price, badge || null, image_url || null, available !== false ? 1 : 0);

  const item = db.prepare('SELECT * FROM menu_items WHERE id = ?').get(result.lastInsertRowid);
  res.status(201).json(item);
});

// ── PATCH /api/menu/:id  (admin) — update existing item ──────────────────────
router.patch('/:id', requireAdmin, (req, res) => {
  const existing = db.prepare('SELECT * FROM menu_items WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Item not found.' });

  const fields = ['category','name','description','price','badge','image_url','available'];
  const updates = [];
  const values  = [];

  fields.forEach(f => {
    if (req.body[f] !== undefined) {
      updates.push(`${f} = ?`);
      values.push(req.body[f]);
    }
  });

  if (updates.length === 0)
    return res.status(400).json({ error: 'No valid fields to update.' });

  updates.push(`updated_at = datetime('now')`);
  values.push(req.params.id);

  db.prepare(`UPDATE menu_items SET ${updates.join(', ')} WHERE id = ?`).run(...values);
  const item = db.prepare('SELECT * FROM menu_items WHERE id = ?').get(req.params.id);
  res.json(item);
});

// ── DELETE /api/menu/:id  (admin) — hard delete ───────────────────────────────
router.delete('/:id', requireAdmin, (req, res) => {
  const existing = db.prepare('SELECT id FROM menu_items WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Item not found.' });

  db.prepare('DELETE FROM menu_items WHERE id = ?').run(req.params.id);
  res.json({ message: 'Item deleted.' });
});

module.exports = router;
